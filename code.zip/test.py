import json

def create_data(filename, wname):
    with open(filename, 'r', encoding='utf-8') as f:
        lines = f.readlines()  # 读取所有行到列表中

    new_data_list = []  # 用于存储所有新数据项的列表

    for line in lines:
        data = json.loads(line)  # 解析JSON字符串
        text = data["text"]
        labels = data["label"]
        for label in labels:
            new_data = {"text": text, "label": label}
            new_data_list.append(new_data)  # 将新数据项添加到列表中

    with open(wname, 'a', encoding='utf-8') as w:
        for new_data in new_data_list:
            w.write(json.dumps(new_data) + '\n')  # 将所有新数据项写入文件

create_data('./data/data/valid.json', './new_data/valid.json')